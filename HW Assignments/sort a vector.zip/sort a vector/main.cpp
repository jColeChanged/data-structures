#include <iostream>
#include "vector.cpp"

using namespace std;

void print_vector(Vector<int> a);
Vector<int> merge(Vector<int> first, Vector<int> second);
Vector<int> merge_sort(Vector<int> to_sort);

int main()
{
	Vector<int> vec1;
	for(int i = 100; i > 0; i--)
	{
		vec1.push_back(i);
	}
	print_vector(merge_sort(vec1));
}

void print_vector(Vector<int> a)
{
	for (int i = 0; i < a.size(); i++)
	{
		cout << a[i] << " ";
	}
	cout << endl;
	return;
}

// Tries to merge two vectors. Assumes that both vector are already sorted in
// ascending order.
Vector<int> merge(Vector<int> first, Vector<int> second)
{
	Vector<int> merge;
	merge.reserve(first.size() + second.size());
	int * first_iter = first.begin();
	int * second_iter = second.begin();
	while (first_iter != first.end() || second_iter != second.end())
	{
		if (first_iter != first.end() && second_iter != second.end())
		{
			if (*first_iter < *second_iter)
			{
				merge.push_back(*first_iter);
				first_iter++;
			}
			else
			{
				merge.push_back(*second_iter);
				second_iter++;
			}
		}
		else if (first_iter != first.end())
		{
			merge.push_back(*first_iter);
			first_iter++;
		}
		else
		{
			merge.push_back(*second_iter);
			second_iter++;
		}
	}
	return merge;
}

Vector<int> merge_sort(Vector<int> to_sort)
{
	if (to_sort.size() == 1)
	{
		return to_sort;
	}
	else
	{
		int split_point = to_sort.size() / 2;
		Vector<int> first_half;
		first_half.reserve(split_point);
		for (int i = 0; i < split_point; i++)
		{
			first_half.push_back(to_sort[i]);
		}
		Vector<int> second_half;
		second_half.reserve(split_point);
		for (int i = split_point; i < to_sort.size(); i++)
		{
			second_half.push_back(to_sort[i]);
		}
		return merge(merge_sort(first_half), merge_sort(second_half));
	}
}
