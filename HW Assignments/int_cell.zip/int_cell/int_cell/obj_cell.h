#ifndef OBJ_CELL_H
#define OBJ_CELL_H


/* A class for simulating an integer memory cell. */
template <class T>
class ObjCell
{
public:
	explicit ObjCell(T initialValue) : storedValue(initialValue) {}
	T read() const { return storedValue; }
	void write(T x) { storedValue = x; }
private:
	T storedValue;
};
#endif

